#include "adminwindow.h"
#include "ui_adminwindow.h"
adminWindow::adminWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::adminWindow)
{
    QSqlQuery query;
    QSqlRecord record;
    QStringList tempList;
    QSqlQueryModel tempModel;

    ui->setupUi(this);
    ui->adminWindow_sortComboBox->addItem("Ascending A-Z");
    ui->adminWindow_sortComboBox->addItem("Descending Z-A");
    ui->adminWindow_sortComboBox->addItem("Interest Level");
    ui->adminWindow_sortComboBox->addItem("Key Customers");

    QObject::connect(this->ui->adminWindow_sortComboBox, SIGNAL(activated(int)), this, SLOT(alphaNumOptions(int)));
    query.prepare("SELECT CompanyName, InterestLevel, KeyCustomer FROM iRobotsPamphlet;");

    if(!query.exec())
        qDebug() << query.lastError();

    tempModel.setQuery(query);
    ui->adminWindow_displayTableView->setModel(&tempModel);
}

adminWindow::~adminWindow()
{
    delete ui;
}

void adminWindow::searchFor()
{
    //Obviously this function is going to be for searching
    QSqlQuery query;
    QSqlRecord record;
    QStringList tempList;
    QString searchingFor = this->ui->adminWindow_searchBar->text();

    query.prepare("SELECT CompanyName, InterestLevel, KeyCustomer FROM iRobotsPamphlet WHERE CompanyName LIKE '%" + searchingFor + "%';");

    if(!query.exec())
        qDebug() << query.lastError();

    while(query.next())
    {
        record = query.record();
        tempList << record.value(0).toString();
    }

    if(tempList.empty())
        QMessageBox::information(this, "Info Box", "Searched string was empty! Search did not find anything of use.");
    else
    {
//        ui->adminWindow_displayListView->clear();
//        ui->adminWindow_displayListView->addItems(tempList);
    }
}

void adminWindow::setupPage()
{

}

void adminWindow::alphaNumOptions(int index)
{
    QSqlQuery query;
    QSqlRecord record;
    QStringList tempList;
    QString option = this->ui->adminWindow_sortComboBox->itemText(index);
    if (option == "Ascending A-Z")
    {
        qDebug() << "Ascending";
        query.prepare("SELECT CompanyName FROM iRobotsPamphlet ORDER BY CustomerName NOCASE ASC;");

        if(!query.exec())
            qDebug() << query.lastError();
    }

    else if (option == "Descending Z-A")
    {
        qDebug() << "Descending";
        query.prepare("SELECT CompanyName FROM iRobotsPamphlet ORDER BY CustomerName NOCASE DESC;");

        if(!query.exec())
            qDebug() << query.lastError();
    }

    if (option == "Interest Level")
    {
        qDebug() << "Alpha works";
        query.prepare("SELECT CompanyName FROM iRobotsPamphlet ORDER BY InterestLevel NOCASE DESC;");

        if(!query.exec())
            qDebug() << query.lastError();
    }

    else if (option == "Key Customers")
    {
        // insert a function to sort by interest
        qDebug() << "Interest works";
        query.prepare("SELECT CompanyName FROM iRobotsPamphlet ORDER BY KeyCustomer NOCASE ASC;");

        if(!query.exec())
            qDebug() << query.lastError();
    }
}

void adminWindow::on_adminWindow_displayListView_activated(const QModelIndex &index)
{

}

void adminWindow::on_adminWindow_refreshButton_clicked()
{

}

void adminWindow::updateDB() {

}

void adminWindow::deleteInDB() {

}
