#ifndef ADMINWINDOW_H
#define ADMINWINDOW_H

#include "header.h"

namespace Ui {
class adminWindow;
}

class adminWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit adminWindow(QWidget *parent = nullptr);
    void setupPage();
    ~adminWindow();

private slots:
    void searchFor();
    void alphaNumOptions(int);
    void updateDB();
    void deleteInDB();

    void on_adminWindow_displayListView_activated(const QModelIndex &index);

    void on_adminWindow_refreshButton_clicked();

private:
    Ui::adminWindow *ui;
};

#endif // ADMINWINDOW_H
