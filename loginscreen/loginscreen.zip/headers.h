#ifndef HEADERS_H
#define HEADERS_H

#include <QCoreApplication>
#include <QApplication>
#include <QMainWindow>
#include <QDebug>

#include <QtSql>
#include <QSqlDatabase>
#include <QSqlDriver>
#include <QSqlError>
#include <QSqlQuery>

#include <QMessageBox>
#include <QDialog>
#include <QPixmap>

#endif // HEADERS_H
